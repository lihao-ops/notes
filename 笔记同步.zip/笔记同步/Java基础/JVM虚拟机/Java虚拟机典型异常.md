# Java 运行时内存区域典型异常知识体系

> **目标**：以异常为中心，串联 JVM 内存区域原理 → 异常复现 → 工具排查 → 解决方案

------

## 一、JVM 运行时内存区域全景

```mermaid
graph TB
    A[JVM运行时内存区域] --> B[线程私有]
    A --> C[线程共享]
    
    B --> B1[程序计数器<br/>无异常]
    B --> B2[虚拟机栈<br/>StackOverflowError<br/>OutOfMemoryError]
    B --> B3[本地方法栈<br/>StackOverflowError<br/>OutOfMemoryError]
    
    C --> C1[堆<br/>OutOfMemoryError: Java heap space<br/>OutOfMemoryError: GC overhead limit]
    C --> C2[方法区/元空间<br/>OutOfMemoryError: Metaspace<br/>OutOfMemoryError: PermGen JDK7]
    C --> C3[直接内存<br/>OutOfMemoryError: Direct buffer memory]
```

------

## 二、核心异常分类与排查体系

### 📌 异常1：StackOverflowError

**触发区域**：虚拟机栈 / 本地方法栈

#### 原理

- 线程请求的栈深度 > JVM 允许的最大深度
- 每次方法调用压栈，栈帧无法弹出时触发

#### 复现代码

```java
public class StackOverflowTest {
    private int depth = 0;
    
    public void recursion() {
        depth++;
        recursion(); // 无终止条件递归
    }
    
    public static void main(String[] args) {
        StackOverflowTest test = new StackOverflowTest();
        try {
            test.recursion();
        } catch (StackOverflowError e) {
            System.out.println("栈深度: " + test.depth);
            e.printStackTrace();
        }
    }
}
```

**JVM 参数**：`-Xss128k` （减小栈空间加速复现）

#### 排查流程

```mermaid
graph LR
    A[StackOverflowError] --> B[查看异常栈]
    B --> C{递归调用?}
    C -->|是| D[检查递归终止条件]
    C -->|否| E[检查方法调用链路]
    E --> F[是否有循环依赖?]
    D --> G[修复代码逻辑]
    F --> G
```

**工具操作**

- **JProfiler**：CPU Views → Call Tree，查看调用深度
- **VisualVM**：Sampler → CPU → 查看热点方法调用栈

#### 解决方案

1. 修复递归终止条件
2. 增大栈空间：`-Xss256k` → `-Xss1m`
3. 改用迭代实现

------

### 📌 异常2：OutOfMemoryError: Java heap space

**触发区域**：堆（Heap）

#### 原理

- 对象无法在堆中分配内存
- GC 后仍无足够连续空间

#### 复现代码

```java
import java.util.*;

public class HeapOOMTest {
    static class OOMObject {
        private byte[] data = new byte[1024 * 1024]; // 1MB
    }
    
    public static void main(String[] args) {
        List<OOMObject> list = new ArrayList<>();
        while (true) {
            list.add(new OOMObject());
        }
    }
}
```

**JVM 参数**：`-Xms20m -Xmx20m -XX:+HeapDumpOnOutOfMemoryError`

#### 排查流程

```mermaid
graph TB
    A[HeapOOM] --> B[生成Heap Dump]
    B --> C[MAT/JProfiler分析]
    C --> D{内存泄漏?}
    D -->|是| E[找到泄漏对象]
    D -->|否| F[内存溢出]
    E --> G[分析GC Roots引用链]
    F --> H[增大堆内存]
    G --> I[修复代码]
```

**工具操作**

**JProfiler**：

1. Heap Walker → Biggest Objects
2. References → Show Paths to GC Root
3. 查看对象引用链

**VisualVM**：

1. 加载 `.hprof` 文件
2. Objects → 按 Retained Size 排序
3. 右键 → Show in Instances View

#### 解决方案

1. **内存泄漏**：修复集合未清理、监听器未注销、ThreadLocal 未 remove
2. **内存溢出**：增大堆：`-Xmx4g`，优化对象生命周期

------

### 📌 异常3：OutOfMemoryError: GC overhead limit exceeded

**触发区域**：堆（Heap）

#### 原理

- GC 时间超过 98%，但回收内存 < 2%
- 表示即将发生 HeapOOM

#### 复现代码

```java
import java.util.*;

public class GCOverheadTest {
    public static void main(String[] args) {
        Map<Integer, String> map = new HashMap<>();
        int i = 0;
        while (true) {
            map.put(i++, new String("value" + i).intern());
        }
    }
}
```

**JVM 参数**：`-Xms10m -Xmx10m -XX:+UseParallelGC`

#### 排查流程

```mermaid
graph LR
    A[GC overhead] --> B[查看GC日志]
    B --> C[分析Full GC频率]
    C --> D[堆内存接近100%]
    D --> E[按HeapOOM流程处理]
```

**工具操作**

- **VisualVM**：Monitor → Perform GC，观察堆使用率
- **JProfiler**：Telemetries → Garbage Collector

#### 解决方案

- 同 HeapOOM 处理方式
- 关闭此检查：`-XX:-UseGCOverheadLimit`（不推荐）

------

### 📌 异常4：OutOfMemoryError: Metaspace

**触发区域**：元空间（JDK8+）

#### 原理

- 类元数据占用空间超过 `-XX:MaxMetaspaceSize`
- 常见于动态代理、热部署

#### 复现代码

```java
import net.sf.cglib.proxy.Enhancer;
import net.sf.cglib.proxy.MethodInterceptor;

public class MetaspaceOOMTest {
    static class OOMObject {}
    
    public static void main(String[] args) {
        while (true) {
            Enhancer enhancer = new Enhancer();
            enhancer.setSuperclass(OOMObject.class);
            enhancer.setUseCache(false);
            enhancer.setCallback((MethodInterceptor) 
                (obj, method, args1, proxy) -> proxy.invokeSuper(obj, args1));
            enhancer.create();
        }
    }
}
```

**JVM 参数**：`-XX:MetaspaceSize=10m -XX:MaxMetaspaceSize=10m`

#### 排查流程

```mermaid
graph TB
    A[Metaspace OOM] --> B[jcmd VM.native_memory]
    B --> C[查看Class Space占用]
    C --> D[jmap -clstats]
    D --> E[统计类加载数量]
    E --> F{类数量异常增长?}
    F -->|是| G[排查动态代理/类加载]
    F -->|否| H[增大Metaspace]
```

**工具操作**

**命令行**：

```bash
jcmd <pid> VM.native_memory summary
jmap -clstats <pid>
```

**JProfiler**：

- Memory → Recorded Objects → 查看 Class 对象数量

**VisualVM**：

- 安装 VisualVM-MBeans 插件
- MBeans → java.lang.ClassLoading → LoadedClassCount

#### 解决方案

1. 增大元空间：`-XX:MaxMetaspaceSize=512m`
2. 检查 ClassLoader 泄漏（Tomcat 热部署）
3. 减少动态代理使用

------

### 📌 异常5：OutOfMemoryError: PermGen space

**触发区域**：永久代（JDK7 及以前）

#### 原理

- 与 Metaspace 类似，但位于堆内
- 存储类信息、常量池、静态变量

#### 复现代码（JDK7）

```java
import java.util.*;

public class PermGenOOMTest {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        int i = 0;
        while (true) {
            list.add(String.valueOf(i++).intern());
        }
    }
}
```

**JVM 参数**（JDK7）：`-XX:PermSize=10m -XX:MaxPermSize=10m`

#### 解决方案

- 升级到 JDK8+
- 或增大 PermGen：`-XX:MaxPermSize=256m`

------

### 📌 异常6：OutOfMemoryError: Direct buffer memory

**触发区域**：直接内存（堆外内存）

#### 原理

- NIO 的 DirectByteBuffer 分配堆外内存
- 超过 `-XX:MaxDirectMemorySize` 限制

#### 复现代码

```java
import java.nio.ByteBuffer;

public class DirectMemoryOOMTest {
    public static void main(String[] args) {
        final int _1MB = 1024 * 1024;
        int count = 0;
        while (true) {
            ByteBuffer.allocateDirect(_1MB);
            System.out.println(++count + "MB");
        }
    }
}
```

**JVM 参数**：`-XX:MaxDirectMemorySize=10m`

#### 排查流程

```mermaid
graph LR
    A[Direct buffer OOM] --> B[检查NIO使用]
    B --> C[是否频繁allocateDirect]
    C --> D[DirectByteBuffer未释放]
    D --> E[手动触发GC或使用Cleaner]
```

**工具操作**

```bash
jcmd <pid> VM.native_memory summary | grep Internal
```

#### 解决方案

1. 增大直接内存：`-XX:MaxDirectMemorySize=512m`
2. 及时释放 DirectByteBuffer
3. 使用池化技术（Netty PooledByteBufAllocator）

------

### 📌 异常7：OutOfMemoryError: unable to create new native thread

**触发区域**：虚拟机栈（线程分配）

#### 原理

- 线程数超过系统限制
- 每个线程分配栈空间，耗尽可用内存

#### 复现代码

```java
public class ThreadOOMTest {
    public static void main(String[] args) {
        int count = 0;
        while (true) {
            new Thread(() -> {
                try {
                    Thread.sleep(Integer.MAX_VALUE);
                } catch (InterruptedException e) {}
            }).start();
            System.out.println(++count);
        }
    }
}
```

#### 排查流程

```mermaid
graph TB
    A[unable to create thread] --> B[查看线程数]
    B --> C{线程数异常?}
    C -->|是| D[排查线程泄漏]
    C -->|否| E[系统限制]
    D --> F[检查线程池配置]
    E --> G[调整ulimit -u]
```

**工具操作**

```bash
jstack <pid> | grep "tid" | wc -l  # 统计线程数
```

**JProfiler**：Threads → Thread History

#### 解决方案

1. 使用线程池，避免无限创建线程
2. 减小栈空间：`-Xss256k`
3. 调整系统限制：`ulimit -u 4096`

------

## 三、工具使用快速索引

### JProfiler 核心功能

| 功能       | 路径                          | 适用场景      |
| ---------- | ----------------------------- | ------------- |
| 堆转储分析 | Heap Walker → Biggest Objects | HeapOOM       |
| GC Root 链 | References → Paths to GC Root | 内存泄漏      |
| 线程分析   | Threads → Thread History      | 线程OOM       |
| 方法调用树 | CPU Views → Call Tree         | StackOverflow |
| 类加载统计 | Memory → Recorded Objects     | Metaspace OOM |

### VisualVM 核心功能

| 功能     | 路径                  | 适用场景       |
| -------- | --------------------- | -------------- |
| 实时监控 | Monitor → Heap/CPU    | 实时诊断       |
| 堆转储   | Heap Dump → Objects   | HeapOOM        |
| 线程快照 | Threads → Thread Dump | 死锁、线程泄漏 |
| 采样分析 | Sampler → CPU/Memory  | 性能分析       |

------

## 四、JVM 参数速查表

```bash
# 堆配置
-Xms2g -Xmx2g                    # 初始/最大堆
-Xmn512m                         # 新生代大小
-XX:SurvivorRatio=8              # Eden:Survivor = 8:1

# 栈配置
-Xss256k                         # 线程栈大小

# 元空间配置
-XX:MetaspaceSize=128m           # 初始元空间
-XX:MaxMetaspaceSize=512m        # 最大元空间

# 直接内存
-XX:MaxDirectMemorySize=512m     # 最大堆外内存

# GC 配置
-XX:+UseG1GC                     # 使用G1垃圾回收器
-XX:+PrintGCDetails              # 打印GC详情
-XX:+HeapDumpOnOutOfMemoryError  # OOM时生成堆转储
-XX:HeapDumpPath=/tmp/dump.hprof # 堆转储路径
```

------

## 五、实战练习 Checklist

- [ ] 复现 StackOverflowError 并使用 JProfiler 分析调用栈
- [ ] 复现 HeapOOM 并使用 MAT/JProfiler 找到泄漏对象
- [ ] 复现 Metaspace OOM 并使用 jcmd 分析类加载情况
- [ ] 复现 Direct buffer OOM 并监控堆外内存
- [ ] 复现线程 OOM 并使用 jstack 分析线程数量
- [ ] 使用 VisualVM 实时监控 GC overhead limit 触发过程
- [ ] 配置 JVM 参数并观察不同配置下的异常触发阈值

------

**记忆口诀**：

> 栈深递归 StackOverflow
>  堆满对象 Heap Space
>  GC 拼命 Overhead
>  类多元空 Metaspace
>  堆外直接 Direct Buffer
>  线程爆炸 Native Thread